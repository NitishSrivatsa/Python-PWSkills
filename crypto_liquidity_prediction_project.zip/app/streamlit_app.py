
import streamlit as st
import pandas as pd
import joblib

model = joblib.load('../models/liquidity_model.pkl')

st.title("Cryptocurrency Liquidity Predictor")

price_ma7 = st.number_input("7-Day Moving Average of Price", min_value=0.0)
volatility_7 = st.number_input("7-Day Price Volatility", min_value=0.0)
liquidity_ratio = st.number_input("Liquidity Ratio (Volume / Market Cap)", min_value=0.0)

if st.button("Predict Liquidity Level"):
    input_df = pd.DataFrame({
        'price_ma7': [price_ma7],
        'volatility_7': [volatility_7],
        'liquidity_ratio': [liquidity_ratio]
    })
    prediction = model.predict(input_df)[0]
    st.success(f"Predicted Liquidity (Normalized Price): {prediction:.4f}")
