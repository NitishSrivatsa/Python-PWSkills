# 01_data_preprocessing.ipynb

# ## Step 1: Imports
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

# ## Step 2: Load Dataset
df = pd.read_csv('../data/crypto_2016_2017.csv')

# ## Step 3: Convert timestamp
df['timestamp'] = pd.to_datetime(df['timestamp'])
df.set_index('timestamp', inplace=True)

# ## Step 4: Normalize numerical features
scaler = MinMaxScaler()
df[['price', 'volume', 'market_cap']] = scaler.fit_transform(df[['price', 'volume', 'market_cap']])

# ## Step 5: Save Processed Data
df.to_csv('../data/processed_crypto_data.csv')
