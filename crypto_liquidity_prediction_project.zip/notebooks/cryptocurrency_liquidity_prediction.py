# cryptocurrency_liquidity_prediction.ipynb

# ## Step 1: Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# ## Step 2: Load Dataset
df = pd.read_csv('../data/crypto_2016_2017.csv')
df['timestamp'] = pd.to_datetime(df['timestamp'])
df.set_index('timestamp', inplace=True)

# ## Step 3: Normalize Features
scaler = MinMaxScaler()
df[['price', 'volume', 'market_cap']] = scaler.fit_transform(df[['price', 'volume', 'market_cap']])

# ## Step 4: Feature Engineering
df['price_ma7'] = df['price'].rolling(window=7).mean()
df['volatility_7'] = df['price'].rolling(window=7).std()
df['liquidity_ratio'] = df['volume'] / (df['market_cap'] + 1e-6)
df.dropna(inplace=True)

# ## Step 5: EDA
plt.figure(figsize=(10, 5))
sns.lineplot(data=df[['price', 'price_ma7']])
plt.title("Price vs 7-Day MA")
plt.savefig('../reports/price_ma7_plot.png')
plt.close()

# ## Step 6: Model Training
X = df[['price_ma7', 'volatility_7', 'liquidity_ratio']]
y = df['price']
model = LinearRegression()
model.fit(X, y)
y_pred = model.predict(X)

# ## Step 7: Evaluation
rmse = np.sqrt(mean_squared_error(y, y_pred))
mae = mean_absolute_error(y, y_pred)
r2 = r2_score(y, y_pred)

print(f"RMSE: {rmse:.4f}")
print(f"MAE: {mae:.4f}")
print(f"R² Score: {r2:.4f}")
